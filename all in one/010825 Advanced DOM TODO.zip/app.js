const form = document.getElementById('todo-form');
const input = document.getElementById('task-input');
const list = document.getElementById('task-list');
// const themeToggleBtn = document.getElementById('theme-toggle');
const themeToggle = document.getElementById('theme-toggle');

let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
let draggedItem = null;
let draggedIndex = null;

// Theme functions
function toggleTheme() {
    const isDark = themeToggle.checked;
    document.documentElement.classList.toggle('dark', isDark);
    document.documentElement.classList.toggle('light', !isDark);
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
}

function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    const isDark = savedTheme === 'dark';
    
    themeToggle.checked = isDark;
    document.documentElement.classList.toggle('dark', isDark);
    document.documentElement.classList.toggle('light', !isDark);
}

// Initialize theme
applySavedTheme();
themeToggle.addEventListener('change', toggleTheme);

// function toggleTheme() {
//   const html = document.documentElement;
//   const currentTheme = localStorage.getItem('theme') || 'dark';
//   const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

//   html.classList.remove(currentTheme);
//   html.classList.add(newTheme);
//   localStorage.setItem('theme', newTheme);
// }

// function applySavedTheme() {
//   const savedTheme = localStorage.getItem('theme') || 'dark';
//   document.documentElement.classList.add(savedTheme);
// }

// applySavedTheme();
// themeToggleBtn.addEventListener('click', toggleTheme);

function saveTasks() {
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

function renderTasks() {
  list.innerHTML = '';
  
  // Separate completed and active tasks
  const completedTasks = tasks.filter(task => task.done);
  const activeTasks = tasks.filter(task => !task.done);
  
  // Render active tasks first (newest first)
  activeTasks.reverse().forEach((task, index) => {
    const li = createTaskElement(task);
    list.appendChild(li);
  });
  
  // Add separator if there are both types
  if (activeTasks.length > 0 && completedTasks.length > 0) {
    const separator = document.createElement('div');
    separator.className = 'text-bold text-green-400 mt-10 mb-10';
    separator.textContent = '✓ Completed Tasks';
    list.appendChild(separator);
  }
  
  // Render completed tasks (newest first)
  completedTasks.reverse().forEach((task, index) => {
    const li = createTaskElement(task);
    list.appendChild(li);
  });
}

function createTaskElement(task) {
  const li = document.createElement('li');
  li.className = 'bg-gray-700 p-3 rounded flex justify-between items-center draggable';
  li.draggable = true;
  li.dataset.id = task.id || Date.now();
  
  if (task.editing) {
    li.innerHTML = `
      <input value="${task.text}" class="flex-1 mr-2 px-2 py-1 bg-gray-600 rounded" />
      <button class="save-btn text-green-400 mr-2">💾</button>
      <button class="cancel-btn text-yellow-400">↩️</button>
    `;
  } else {
    li.innerHTML = `
      <span class="${task.done ? 'line-through text-green-100 opacity-40 transition-all duration-300' : ''}">${task.text}</span>
      <div class="space-x-2">
        <button class="edit-btn text-yellow-300">✏️</button>
        <button class="remove-btn text-red-400">❌</button>
        <button class="cross-procrastination p-3 bg-green-500 text-white"><p>✅</p></button>
      </div>
    `;
  }

  li.querySelector('.remove-btn')?.addEventListener('click', () => {
    tasks = tasks.filter(t => t !== task);
    saveTasks();
    renderTasks();
  });

  li.querySelector('.edit-btn')?.addEventListener('click', () => {
    task.editing = true;
    saveTasks();
    renderTasks();
  });

  li.querySelector('.cancel-btn')?.addEventListener('click', () => {
    task.editing = false;
    saveTasks();
    renderTasks();
  });

  li.querySelector('.save-btn')?.addEventListener('click', () => {
    const newText = li.querySelector('input').value.trim();
    if (newText) {
      task.text = newText;
      task.editing = false;
      saveTasks();
      renderTasks();
    }
  });

  li.querySelector('.cross-procrastination')?.addEventListener('click', () => {
    task.done = !task.done;
    saveTasks();
    renderTasks();
  });

  return li;
}

// Event listeners for drag and drop
list.addEventListener('dragstart', handleDragStart);
list.addEventListener('dragover', handleDragOver);
list.addEventListener('dragenter', handleDragEnter);
list.addEventListener('dragleave', handleDragLeave);
list.addEventListener('drop', handleDrop);
list.addEventListener('dragend', handleDragEnd);

function handleDragStart(e) {
  if (!e.target.classList.contains('draggable')) return;

  draggedItem = e.target;
  draggedIndex = Array.from(list.children).indexOf(draggedItem);

  e.target.classList.add('opacity-50', 'border-2', 'border-dashed', 'border-blue-400');

  e.dataTransfer.setData('text/plain', e.target.dataset.id);

  e.dataTransfer.setDragImage(e.target, 0, 0);
}

function handleDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
}

function handleDragEnter(e) {
  if (!e.target.closest('.draggable') || e.target === draggedItem) return;

  const targetItem = e.target.closest('.draggable');
  const rect = targetItem.getBoundingClientRect();
  const middleY = rect.top + rect.height / 2;

  if (e.clientY < middleY) {
    targetItem.classList.add('border-t-4', 'border-blue-500');
    targetItem.classList.remove('border-b-4');    
  } else {
    targetItem.classList.add('border-b-4', 'border-blue-500');
    targetItem.classList.remove('border-t-4');    
  }
}

function handleDragLeave(e) {
  if (!e.target.classList.contains('draggable')) return;
  e.target.classList.remove('border-t-4', 'border-b-4', 'border-blue-500');
}

function handleDrop(e) {
  e.preventDefault();
  if (!draggedItem || !e.target.closest('.draggable')) return;

  const targetItem = e.target.closest('.draggable');
  const rect = targetItem.getBoundingClientRect();
  const middleY = rect.top + rect.height / 2;

  list.querySelectorAll('.draggable').forEach(item => {
    item.classList.remove('border-t-4', 'border-b-4', 'border-blue-500');
  });

  if (e.clientY < middleY) {
    list.insertBefore(draggedItem, targetItem);
  } else {
    list.insertBefore(draggedItem, targetItem.nextSibling);
  }
  
  updateTaskOrder();
}

function handleDragEnd(e) {
  if (!e.target.classList.contains('draggable')) return;

  e.target.classList.remove('opacity-50', 'border-2', 'border-dashed', 'border-blue-400');

  draggedItem = null;
  draggedIndex = null;
}

function updateTaskOrder() {
  const newTasks = [];
  const items = list.querySelectorAll('.draggable');

  items.forEach(item => {
    const taskId = item.dataset.id;
    const originalTask = tasks.find(task => (task.id || task.text) === taskId);
    if (originalTask) {
      newTasks.push(originalTask);
    }
  });

  tasks = newTasks;
  saveTasks();
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (text) {
    tasks.push({
      text,
      editing: false,
      done: false,
      id: Date.now().toString()
    });
    input.value = '';
    saveTasks();
    renderTasks();
  }
});

// First render
renderTasks();