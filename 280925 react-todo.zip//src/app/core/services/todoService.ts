// todoService.ts
import { TodoStatus, Todo } from "../utils/constants";

const STORAGE_KEY = "todos-app-data";
const QUEUE_KEY = "todos-pending-queue";

// Initialize todos from localStorage or empty array
let todos: Todo[] = loadTodosFromStorage();
let pendingDoneQueue: { id: string; completeAt: number }[] =
  loadPendingQueueFromStorage();

// Load todos from localStorage
function loadTodosFromStorage(): Todo[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error("Error loading todos from storage:", error);
    return [];
  }
}

// Load pending queue from localStorage
function loadPendingQueueFromStorage(): { id: string; completeAt: number }[] {
  try {
    const stored = localStorage.getItem(QUEUE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error("Error loading pending queue from storage:", error);
    return [];
  }
}

// Save todos to localStorage
function saveTodosToStorage(): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
  } catch (error) {
    console.error("Error saving todos to storage:", error);
  }
}

// Save pending queue to localStorage
function savePendingQueueToStorage(): void {
  try {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(pendingDoneQueue));
  } catch (error) {
    console.error("Error saving pending queue to storage:", error);
  }
}

// Get all todos
export function getTodos(): Todo[] {
  return todos;
}

// Add new todo WITH time parameter
export function addTodo(text: string, time?: string) {
  const now = new Date();
  const todo: Todo = {
    id: crypto.randomUUID(),
    text,
    status: TodoStatus.ACTIVE,
    createdAt: now.toISOString(),
    time: time || undefined,
  };
  todos.push(todo);
  saveTodosToStorage();
  return todo;
}

// Update todo text AND time
export function updateTodo(id: string, newText: string, newTime?: string) {
  const todo = todos.find((t) => t.id === id);
  if (todo) {
    todo.text = newText;
    if (newTime !== undefined) {
      todo.time = newTime;
    }
    todo.updatedAt = new Date().toISOString();
    saveTodosToStorage();
  }
}

// Add function to update only time
export function updateTodoTime(id: string, time: string) {
  const todo = todos.find((t) => t.id === id);
  if (todo) {
    todo.time = time;
    todo.updatedAt = new Date().toISOString();
    saveTodosToStorage();
  }
}

// Mark todo as done with 30-min delay
export function markDone(id: string) {
  const todo = todos.find((t) => t.id === id);
  if (todo && todo.status === TodoStatus.ACTIVE) {
    const completeAt = Date.now() + 30 * 60 * 1000; // 30 minutes
    pendingDoneQueue.push({ id, completeAt });
    savePendingQueueToStorage(); // Save queue to localStorage
  }
}

// Periodically check pending queue and save when todos change
setInterval(() => {
  const now = Date.now();
  let shouldSave = false;

  pendingDoneQueue = pendingDoneQueue.filter(({ id, completeAt }) => {
    if (now >= completeAt) {
      const todo = todos.find((t) => t.id === id);
      if (todo) {
        todo.status = TodoStatus.DONE;
        todo.completedAt = new Date().toISOString();
        shouldSave = true;
      }
      return false; // remove from queue
    }
    return true;
  });

  if (shouldSave) {
    saveTodosToStorage();
    savePendingQueueToStorage(); // Update queue after filtering
  }
}, 1000);

export function getPendingDoneUntil(id: string) {
  const item = pendingDoneQueue.find((t) => t.id === id);
  return item?.completeAt;
}

// Move to Deleted
export function deleteTodo(id: string, fromDone = false) {
  const todo = todos.find((t) => t.id === id);
  if (todo) {
    todo.status = TodoStatus.DELETED;
    todo.deletedAt = new Date().toISOString();
    todo.deletedFromDone = fromDone;

    // Remove from pending queue if it's there
    const queueIndex = pendingDoneQueue.findIndex((item) => item.id === id);
    if (queueIndex !== -1) {
      pendingDoneQueue.splice(queueIndex, 1);
      savePendingQueueToStorage();
    }

    saveTodosToStorage();
  }
}

// Permanently remove
export function removeTodoPermanently(id: string) {
  todos = todos.filter((t) => t.id !== id);

  // Remove from pending queue if it's there
  const queueIndex = pendingDoneQueue.findIndex((item) => item.id === id);
  if (queueIndex !== -1) {
    pendingDoneQueue.splice(queueIndex, 1);
    savePendingQueueToStorage();
  }

  saveTodosToStorage();
}

export function recoverTodo(id: string) {
  const todo = todos.find((t) => t.id === id);
  if (todo && todo.status === TodoStatus.DELETED) {
    todo.status = todo.deletedFromDone ? TodoStatus.DONE : TodoStatus.ACTIVE;
    todo.deletedAt = undefined;
    todo.deletedFromDone = undefined;
    saveTodosToStorage();
  }
}

// Add utility function to clear all data (for testing)
export function clearAllTodos(): void {
  todos = [];
  pendingDoneQueue = [];
  localStorage.removeItem(STORAGE_KEY);
  localStorage.removeItem(QUEUE_KEY);
}

// Add function to export/import data
export function exportTodos(): string {
  return JSON.stringify(
    {
      todos: todos,
      pendingQueue: pendingDoneQueue,
      exportedAt: new Date().toISOString(),
    },
    null,
    2
  );
}

export function importTodos(jsonData: string): boolean {
  try {
    const data = JSON.parse(jsonData);
    if (data.todos && Array.isArray(data.todos)) {
      todos = data.todos;
      if (data.pendingQueue && Array.isArray(data.pendingQueue)) {
        pendingDoneQueue = data.pendingQueue;
      }
      saveTodosToStorage();
      savePendingQueueToStorage();
      return true;
    }
    return false;
  } catch (error) {
    console.error("Error importing todos:", error);
    return false;
  }
}

// Clean up expired pending items on startup
function cleanupExpiredPendingItems() {
  const now = Date.now();
  const initialLength = pendingDoneQueue.length;

  pendingDoneQueue = pendingDoneQueue.filter(({ id, completeAt }) => {
    if (now >= completeAt) {
      const todo = todos.find((t) => t.id === id);
      if (todo && todo.status === TodoStatus.ACTIVE) {
        todo.status = TodoStatus.DONE;
        todo.completedAt = new Date().toISOString();
      }
      return false;
    }
    return true;
  });

  if (pendingDoneQueue.length !== initialLength) {
    saveTodosToStorage();
    savePendingQueueToStorage();
  }
}

// Run cleanup on module load
cleanupExpiredPendingItems();
