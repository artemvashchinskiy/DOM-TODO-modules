//contacts.ts

// constants.ts
export enum TodoStatus {
  ACTIVE = "active",
  DONE = "done",
  DELETED = "deleted",
}

export interface Todo {
  id: string;
  text: string;
  status: TodoStatus;
  createdAt: string;
  updatedAt?: string;
  deletedAt?: string;
  completedAt?: string;
  deletedFromDone?: boolean;
  time?: string; // ADD THIS LINE - make it optional
}
