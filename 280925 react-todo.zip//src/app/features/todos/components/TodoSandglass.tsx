// TodoSandglass.tsx
import React from "react";
import { Todo } from "../../core/services/todoService";

interface TodoSandglassProps {
  todos: Todo[];
}

const periods = [
  { label: "Morning", start: 5, end: 11 }, // 5:00 - 11:59
  { label: "Afternoon", start: 12, end: 16 }, // 12:00 - 16:59
  { label: "Evening", start: 17, end: 20 }, // 17:00 - 20:59
  { label: "Night", start: 21, end: 4 }, // 21:00 - 4:59
  { label: "No Time Set", start: -1, end: -1 }, // Special period for todos without time
];

export default function TodoSandglass({ todos }: TodoSandglassProps) {
  // Helper: check if hour belongs to period
  const inPeriod = (hour: number, periodStart: number, periodEnd: number) => {
    if (periodStart === -1 && periodEnd === -1) return false; // Special case for "No Time Set"
    if (periodStart <= periodEnd)
      return hour >= periodStart && hour <= periodEnd;
    // For periods wrapping over midnight
    return hour >= periodStart || hour <= periodEnd;
  };

  // Group todos by period
  const groupedTodos = periods.map((period) => {
    if (period.label === "No Time Set") {
      // Special handling for todos without time
      const items = todos.filter((todo) => !todo.time);
      return { ...period, items };
    }

    const items = todos.filter((todo) => {
      if (!todo.time) return false;
      const [hh] = todo.time.split(":").map(Number);
      return inPeriod(hh, period.start, period.end);
    });
    return { ...period, items };
  });

  return (
    <div className="flex flex-col gap-6 p-4 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-semibold text-gray-800 text-center">
        ⏳ Todo Sandglass
      </h2>
      {groupedTodos.map((group) => (
        <div key={group.label} className="flex flex-col gap-2">
          <h3 className="text-lg font-medium text-gray-700">{group.label}</h3>
          <div className="flex flex-col gap-1 border-l-4 border-gray-200 pl-3">
            {group.items.length === 0 && (
              <p className="text-gray-400 italic text-sm">No tasks</p>
            )}
            {group.items.map((todo) => (
              <div
                key={todo.id}
                className={`flex justify-between items-center p-2 rounded ${
                  todo.status === "done"
                    ? "bg-gray-100 text-gray-500 line-through"
                    : "bg-blue-50 text-blue-800"
                }`}
              >
                <span>{todo.text}</span>
                <span className="text-xs font-mono">
                  {todo.time || "No time"}
                  {todo.status === "done" ? " ✅" : ""}
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
