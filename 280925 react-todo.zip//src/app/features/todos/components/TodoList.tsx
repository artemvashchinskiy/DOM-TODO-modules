// TodoList.tsx
import { Todo } from "../../../core/services/todoService";
import TodoItem from "./TodoItem";

interface Props {
  todos: Todo[];
  refresh: () => void;
}

export default function TodoList({ todos, refresh }: Props) {
  if (todos.length === 0) {
    return (
      <div className="text-gray-500 text-center py-4">
        <p>No active tasks</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {todos.map((todo) => (
        <TodoItem key={todo.id} todo={todo} onChange={refresh} />
      ))}
    </div>
  );
}
