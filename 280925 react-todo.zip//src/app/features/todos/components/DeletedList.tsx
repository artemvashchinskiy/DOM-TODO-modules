// DeletedList.tsx
import {
  Todo,
  recoverTodo,
  removeTodoPermanently,
} from "../../../core/services/todoService";
import { formatDate } from "../../../core/utils/dateUtils";

interface Props {
  todos: Todo[];
  refresh: () => void;
}

export default function DeletedList({ todos, refresh }: Props) {
  if (todos.length === 0) {
    return (
      <div className="text-gray-500 text-center py-8 bg-gray-50 rounded-lg">
        <p className="text-lg">No deleted tasks</p>
        <p className="text-sm mt-1">Deleted tasks will appear here</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {todos.map((todo) => (
        <div
          key={todo.id}
          className="border border-gray-200 rounded-xl p-4 bg-white shadow-sm hover:shadow-md transition-shadow"
        >
          {/* Top Section */}
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-3">
            {/* Todo Text */}
            <div className="flex-1 min-w-0">
              <p
                className={`text-base font-medium break-words whitespace-normal ${
                  todo.deletedFromDone
                    ? "text-gray-500 line-through"
                    : "text-gray-800"
                }`}
              >
                {todo.text}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-row sm:flex-col gap-2 sm:w-auto">
              <button
                onClick={() => {
                  recoverTodo(todo.id);
                  refresh();
                }}
                className="px-4 py-2 text-sm bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors font-medium"
              >
                Recover
              </button>
              <button
                onClick={() => {
                  removeTodoPermanently(todo.id);
                  refresh();
                }}
                disabled={!todo.deletedFromDone}
                className={`px-4 py-2 text-sm rounded-lg font-medium transition-colors ${
                  todo.deletedFromDone
                    ? "bg-red-500 hover:bg-red-600 text-white"
                    : "bg-gray-200 text-gray-400 cursor-not-allowed"
                }`}
              >
                Delete
              </button>
            </div>
          </div>

          {/* Metadata Row */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-gray-600">
            {todo.deletedAt && (
              <div className="flex items-center gap-1">
                <span className="font-medium">Deleted:</span>
                <span>{formatDate(new Date(todo.deletedAt))}</span>
              </div>
            )}

            <div className="flex items-center gap-1">
              <span className="font-medium">Time:</span>
              <span>{todo.time || "Not set"}</span>
            </div>

            {todo.deletedFromDone && (
              <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full font-medium">
                From Done
              </span>
            )}
          </div>

          {/* Additional Info */}
          {(todo.completedAt || todo.createdAt) && (
            <div className="mt-3 flex flex-wrap gap-2">
              {todo.completedAt && (
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                  Completed: {formatDate(new Date(todo.completedAt))}
                </span>
              )}
              {todo.createdAt && (
                <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs">
                  Created: {formatDate(new Date(todo.createdAt))}
                </span>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
