// TodoItem.tsx - Fix any potential numbering issues
import { useEffect, useState } from "react";
import {
  Todo,
  markDone,
  deleteTodo,
  getPendingDoneUntil,
  updateTodoTime,
} from "../../../core/services/todoService";
import { TodoStatus } from "../../../core/utils/constants";
import { formatDate } from "../../../core/utils/dateUtils";

interface Props {
  todo: Todo;
  onChange: () => void;
}

export default function TodoItem({ todo, onChange }: Props) {
  const [editingTime, setEditingTime] = useState(false);
  const [newTime, setNewTime] = useState(todo.time || "12:00");
  const [pendingUntil, setPendingUntil] = useState<number | undefined>(
    undefined
  );
  const [remaining, setRemaining] = useState<number>(0);

  // Update pendingUntil when todo changes or on mount
  useEffect(() => {
    const until = getPendingDoneUntil(todo.id);
    setPendingUntil(until);

    if (until) {
      const sec = Math.max(Math.floor((until - Date.now()) / 1000), 0);
      setRemaining(sec);
    }
  }, [todo.id]);

  useEffect(() => {
    if (!pendingUntil) return;

    const interval = setInterval(() => {
      const sec = Math.max(Math.floor((pendingUntil - Date.now()) / 1000), 0);
      setRemaining(sec);

      if (sec <= 0) {
        clearInterval(interval);
        onChange();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [pendingUntil, onChange]);

  const handleMarkDone = () => {
    markDone(todo.id);
    const newPendingUntil = Date.now() + 30 * 60 * 1000;
    setPendingUntil(newPendingUntil);
    setRemaining(30 * 60);
    onChange();
  };

  const handleSaveTime = () => {
    updateTodoTime(todo.id, newTime);
    setEditingTime(false);
    onChange();
  };

  const getTimeDisplay = () => {
    if (remaining <= 0) return null;
    const minutes = Math.floor(remaining / 60);
    const seconds = remaining % 60;
    return `Complete in ${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  };

  const timeDisplay = getTimeDisplay();

  return (
    <div className="border border-gray-200 rounded-lg p-4 mb-3 bg-white shadow-sm hover:shadow-md transition-shadow">
      {/* Main Content Row */}
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-3">
        {/* Todo Text - Ensure no extra numbers appear */}
        <div className="flex-1 min-w-0">
          <p
            className={`text-base font-medium break-words ${
              todo.status === TodoStatus.DONE
                ? "line-through text-gray-500"
                : "text-gray-800"
            }`}
          >
            {todo.text}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex sm:flex-col gap-2 sm:gap-1 flex-shrink-0">
          {todo.status === TodoStatus.ACTIVE && (
            <>
              <button
                onClick={handleMarkDone}
                className={`px-3 py-2 text-sm rounded transition-colors ${
                  pendingUntil
                    ? "bg-yellow-500 hover:bg-yellow-600 text-white"
                    : "bg-green-500 hover:bg-green-600 text-white"
                }`}
                disabled={!!pendingUntil}
              >
                {pendingUntil ? "⏳" : "✓"}
              </button>
              <button
                onClick={() => {
                  deleteTodo(todo.id);
                  onChange();
                }}
                className="px-3 py-2 text-sm bg-red-500 hover:bg-red-600 text-white rounded transition-colors"
              >
                🗑️
              </button>
            </>
          )}
        </div>
      </div>

      {/* Metadata Row */}
      <div className="space-y-2">
        {/* Created Date */}
        <div className="flex flex-wrap gap-4 text-xs text-gray-500">
          <span>Created: {formatDate(new Date(todo.createdAt))}</span>
        </div>

        {/* Time Editing */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-600 font-medium">Time:</span>
            {editingTime ? (
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  className="border border-gray-300 rounded px-2 py-1 text-xs"
                />
                <button
                  onClick={handleSaveTime}
                  className="bg-blue-500 text-white px-2 py-1 rounded text-xs hover:bg-blue-600 transition-colors"
                >
                  Save
                </button>
                <button
                  onClick={() => setEditingTime(false)}
                  className="bg-gray-500 text-white px-2 py-1 rounded text-xs hover:bg-gray-600 transition-colors"
                >
                  X
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="text-sm">{todo.time || "Not set"}</span>
                <button
                  onClick={() => setEditingTime(true)}
                  className="text-blue-500 hover:text-blue-700 text-xs transition-colors"
                >
                  {todo.time ? "Edit" : "Add Time"}
                </button>
              </div>
            )}
          </div>

          {/* Status Indicators */}
          <div className="flex items-center gap-3">
            {timeDisplay && (
              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full font-medium">
                ⏳ {timeDisplay}
              </span>
            )}
            {todo.status === TodoStatus.DONE && todo.completedAt && (
              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full font-medium">
                ✅ Done
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
