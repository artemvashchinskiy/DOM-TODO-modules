// DoneList.tsx
import { Todo, deleteTodo } from "../../../core/services/todoService";
import { formatDate } from "../../../core/utils/dateUtils";

interface Props {
  todos: Todo[];
  refresh: () => void;
}

export default function DoneList({ todos, refresh }: Props) {
  if (todos.length === 0) {
    return (
      <div className="text-gray-500 text-center py-8 bg-gray-50 rounded-lg">
        <p className="text-lg">No completed tasks yet</p>
        <p className="text-sm mt-1">Complete some tasks to see them here</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {todos.map((todo) => (
        <div
          key={todo.id}
          className="border border-gray-200 rounded-lg p-4 bg-green-50 shadow-sm"
        >
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-3">
            {/* Todo Text */}
            <div className="flex-1 min-w-0">
              <p className="text-base font-medium text-gray-700 line-through break-words">
                {todo.text}
              </p>
            </div>

            {/* Action Button */}
            <button
              onClick={() => {
                deleteTodo(todo.id, true);
                refresh();
              }}
              className="px-4 py-2 text-sm bg-red-500 hover:bg-red-600 text-white rounded transition-colors flex-shrink-0"
            >
              Delete
            </button>
          </div>

          <div className="flex flex-wrap gap-4 text-xs text-gray-600">
            <span>
              Completed:{" "}
              {todo.completedAt && formatDate(new Date(todo.completedAt))}
            </span>
            <span>Time: {todo.time || "Not set"}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
