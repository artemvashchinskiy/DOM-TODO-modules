// ClockCanvas.tsx

import { useEffect, useRef, useState } from "react";
import { Todo } from "../../core/services/todoService";

interface ClockCanvasProps {
  todos: Todo[];
}

export default function ClockCanvas({ todos }: ClockCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000); // Update every second for smoother animation

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    drawClock(ctx, canvas.width, canvas.height);
  }, [todos, currentTime]);

  const drawClock = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number
  ) => {
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(centerX, centerY) - 10;

    // Clear canvas with a light background
    ctx.clearRect(0, 0, width, height);

    // Draw clock face with background
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    ctx.fillStyle = "#f8f9fa";
    ctx.fill();
    ctx.strokeStyle = "#333";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw clock center
    ctx.beginPath();
    ctx.arc(centerX, centerY, 4, 0, 2 * Math.PI);
    ctx.fillStyle = "#333";
    ctx.fill();

    // Draw numbers
    ctx.font = "16px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#333";

    for (let h = 1; h <= 12; h++) {
      const angle = ((h - 3) * (Math.PI * 2)) / 12;
      const x = centerX + Math.cos(angle) * (radius - 20);
      const y = centerY + Math.sin(angle) * (radius - 20);
      ctx.fillText(h.toString(), x, y);
    }

    // Draw minute markers
    for (let i = 0; i < 60; i++) {
      if (i % 5 !== 0) {
        // Skip where numbers are
        const angle = (i * 6 - 90) * (Math.PI / 180);
        const x1 = centerX + Math.cos(angle) * (radius - 5);
        const y1 = centerY + Math.sin(angle) * (radius - 5);
        const x2 = centerX + Math.cos(angle) * radius;
        const y2 = centerY + Math.sin(angle) * radius;

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.strokeStyle = "#999";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }

    // Draw current time arrows
    const now = currentTime;
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    // Hour hand
    const hourAngle = (((hours % 12) + minutes / 60 - 3) * (Math.PI * 2)) / 12;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(
      centerX + Math.cos(hourAngle) * (radius - 40),
      centerY + Math.sin(hourAngle) * (radius - 40)
    );
    ctx.strokeStyle = "#333";
    ctx.lineWidth = 4;
    ctx.stroke();

    // Minute hand
    const minuteAngle = ((minutes + seconds / 60 - 15) * (Math.PI * 2)) / 60;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(
      centerX + Math.cos(minuteAngle) * (radius - 25),
      centerY + Math.sin(minuteAngle) * (radius - 25)
    );
    ctx.strokeStyle = "#666";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Second hand
    const secondAngle = ((seconds - 15) * (Math.PI * 2)) / 60;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(
      centerX + Math.cos(secondAngle) * (radius - 20),
      centerY + Math.sin(secondAngle) * (radius - 20)
    );
    ctx.strokeStyle = "red";
    ctx.lineWidth = 1;
    ctx.stroke();

    // Draw task arcs and labels
    todos.forEach((todo) => {
      if (todo.status !== "deleted" && todo.time) {
        const [hh, mm] = todo.time.split(":").map(Number);
        const angle = (((hh % 12) + mm / 60 - 3) * (Math.PI * 2)) / 12;
        const x = centerX + Math.cos(angle) * (radius - 50);
        const y = centerY + Math.sin(angle) * (radius - 50);

        // Draw arc indicator at the task time
        ctx.beginPath();
        ctx.arc(x, y, 8, 0, 2 * Math.PI);
        ctx.fillStyle =
          todo.status === "done"
            ? "rgba(156, 163, 175, 0.7)"
            : "rgba(59, 130, 246, 0.7)";
        ctx.fill();
        ctx.strokeStyle = todo.status === "done" ? "#4b5563" : "#1d4ed8";
        ctx.lineWidth = 2;
        ctx.stroke();

        // Draw connecting line to task text
        ctx.beginPath();
        ctx.moveTo(x, y);
        const textX = x + 25 * Math.cos(angle);
        const textY = y + 25 * Math.sin(angle);
        ctx.lineTo(textX, textY);
        ctx.strokeStyle =
          todo.status === "done"
            ? "rgba(156, 163, 175, 0.5)"
            : "rgba(59, 130, 246, 0.5)";
        ctx.lineWidth = 1;
        ctx.stroke();

        // Draw task text with background for better readability
        const text =
          todo.text.length > 15
            ? todo.text.substring(0, 12) + "..."
            : todo.text;
        const textWidth = ctx.measureText(text).width;

        // Text background
        ctx.fillStyle =
          todo.status === "done"
            ? "rgba(156, 163, 175, 0.2)"
            : "rgba(59, 130, 246, 0.2)";
        ctx.fillRect(textX - textWidth / 2 - 5, textY - 10, textWidth + 10, 20);

        // Task text
        ctx.fillStyle = todo.status === "done" ? "#4b5563" : "#1e40af";
        ctx.font = "bold 12px Arial";
        ctx.fillText(text, textX, textY + 4);

        // Time label below task text
        ctx.fillStyle = todo.status === "done" ? "#6b7280" : "#3b82f6";
        ctx.font = "10px Arial";
        ctx.fillText(todo.time, textX, textY + 18);
      }
    });

    // Draw legend
    ctx.fillStyle = "#333";
    ctx.font = "12px Arial";
    ctx.fillText("Current time", centerX, centerY + radius + 30);

    // Draw active task indicator in legend
    ctx.beginPath();
    ctx.arc(centerX - 40, centerY + radius + 30, 6, 0, 2 * Math.PI);
    ctx.fillStyle = "rgba(59, 130, 246, 0.7)";
    ctx.fill();
    ctx.strokeStyle = "#1d4ed8";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = "#1e40af";
    ctx.fillText("Active task", centerX - 25, centerY + radius + 34);

    // Draw completed task indicator in legend
    ctx.beginPath();
    ctx.arc(centerX + 30, centerY + radius + 30, 6, 0, 2 * Math.PI);
    ctx.fillStyle = "rgba(156, 163, 175, 0.7)";
    ctx.fill();
    ctx.strokeStyle = "#4b5563";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = "#4b5563";
    ctx.fillText("Done task", centerX + 45, centerY + radius + 34);
  };

  const exportPNG = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement("a");
    link.download = "todo-clock.png";
    link.href = canvas.toDataURL("image/png");
    link.click();
  };

  const exportSVG = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 10;
    const now = currentTime;
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    const hourAngle = (((hours % 12) + minutes / 60 - 3) * (Math.PI * 2)) / 12;
    const minuteAngle = ((minutes + seconds / 60 - 15) * (Math.PI * 2)) / 60;

    const hourX = centerX + Math.cos(hourAngle) * (radius - 40);
    const hourY = centerY + Math.sin(hourAngle) * (radius - 40);
    const minuteX = centerX + Math.cos(minuteAngle) * (radius - 25);
    const minuteY = centerY + Math.sin(minuteAngle) * (radius - 25);

    let svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${canvas.width}" height="${canvas.height}" viewBox="0 0 ${canvas.width} ${canvas.height}">
        <circle cx="${centerX}" cy="${centerY}" r="${radius}" fill="#f8f9fa" stroke="#333" stroke-width="2" />
    `;

    // Minute markers
    for (let i = 0; i < 60; i++) {
      if (i % 5 !== 0) {
        const angle = (i * 6 - 90) * (Math.PI / 180);
        const x1 = centerX + Math.cos(angle) * (radius - 5);
        const y1 = centerY + Math.sin(angle) * (radius - 5);
        const x2 = centerX + Math.cos(angle) * radius;
        const y2 = centerY + Math.sin(angle) * radius;

        svg += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#999" stroke-width="1" />`;
      }
    }

    // Numbers
    for (let h = 1; h <= 12; h++) {
      const angle = ((h - 3) * (Math.PI * 2)) / 12;
      const x = centerX + Math.cos(angle) * (radius - 20);
      const y = centerY + Math.sin(angle) * (radius - 20);
      svg += `<text x="${x}" y="${y}" text-anchor="middle" alignment-baseline="middle" font-size="16" fill="#333">${h}</text>`;
    }

    // Clock center
    svg += `<circle cx="${centerX}" cy="${centerY}" r="4" fill="#333" />`;

    // Hour hand
    svg += `<line x1="${centerX}" y1="${centerY}" x2="${hourX}" y2="${hourY}" stroke="#333" stroke-width="4"/>`;

    // Minute hand
    svg += `<line x1="${centerX}" y1="${centerY}" x2="${minuteX}" y2="${minuteY}" stroke="#666" stroke-width="2"/>`;

    // Tasks
    todos.forEach((todo) => {
      if (todo.status !== "deleted" && todo.time) {
        const [hh, mm] = todo.time.split(":").map(Number);
        const angle = (((hh % 12) + mm / 60 - 3) * (Math.PI * 2)) / 12;
        const x = centerX + Math.cos(angle) * (radius - 50);
        const y = centerY + Math.sin(angle) * (radius - 50);
        const color = todo.status === "done" ? "gray" : "blue";
        const fillColor =
          todo.status === "done"
            ? "rgba(156, 163, 175, 0.7)"
            : "rgba(59, 130, 246, 0.7)";
        const strokeColor = todo.status === "done" ? "#4b5563" : "#1d4ed8";
        const textColor = todo.status === "done" ? "#4b5563" : "#1e40af";

        // Task indicator
        svg += `<circle cx="${x}" cy="${y}" r="8" fill="${fillColor}" stroke="${strokeColor}" stroke-width="2"/>`;

        // Connecting line
        const textX = x + 25 * Math.cos(angle);
        const textY = y + 25 * Math.sin(angle);
        svg += `<line x1="${x}" y1="${y}" x2="${textX}" y2="${textY}" stroke="${fillColor}" stroke-width="1" stroke-opacity="0.5"/>`;

        // Task text with background
        const text =
          todo.text.length > 15
            ? todo.text.substring(0, 12) + "..."
            : todo.text;
        const textWidth = text.length * 7; // Approximate width

        svg += `<rect x="${textX - textWidth / 2 - 5}" y="${
          textY - 10
        }" width="${textWidth + 10}" height="20" fill="${
          todo.status === "done"
            ? "rgba(156, 163, 175, 0.2)"
            : "rgba(59, 130, 246, 0.2)"
        }" rx="3"/>`;
        svg += `<text x="${textX}" y="${
          textY + 4
        }" text-anchor="middle" font-size="12" font-weight="bold" fill="${textColor}">${text}</text>`;
        svg += `<text x="${textX}" y="${
          textY + 18
        }" text-anchor="middle" font-size="10" fill="${
          todo.status === "done" ? "#6b7280" : "#3b82f6"
        }">${todo.time}</text>`;
      }
    });

    // Legend
    svg += `<text x="${centerX}" y="${
      centerY + radius + 30
    }" text-anchor="middle" font-size="12" fill="#333">Current time</text>`;
    svg += `<circle cx="${centerX - 40}" cy="${
      centerY + radius + 30
    }" r="6" fill="rgba(59, 130, 246, 0.7)" stroke="#1d4ed8" stroke-width="1"/>`;
    svg += `<text x="${centerX - 25}" y="${
      centerY + radius + 34
    }" text-anchor="start" font-size="12" fill="#1e40af">Active task</text>`;
    svg += `<circle cx="${centerX + 30}" cy="${
      centerY + radius + 30
    }" r="6" fill="rgba(156, 163, 175, 0.7)" stroke="#4b5563" stroke-width="1"/>`;
    svg += `<text x="${centerX + 45}" y="${
      centerY + radius + 34
    }" text-anchor="start" font-size="12" fill="#4b5563">Done task</text>`;

    svg += `</svg>`;

    const blob = new Blob([svg], { type: "image/svg+xml" });
    const link = document.createElement("a");
    link.download = "todo-clock.svg";
    link.href = URL.createObjectURL(blob);
    link.click();
  };

  // Check for task announcements
  useEffect(() => {
    const checkTaskAnnouncements = () => {
      const now = new Date();
      const hh = now.getHours().toString().padStart(2, "0");
      const mm = now.getMinutes().toString().padStart(2, "0");
      const currentHM = `${hh}:${mm}`;

      todos.forEach((todo) => {
        if (todo.status === "active" && todo.time === currentHM) {
          // Visual notification
          alert(`⏰ Time for task: ${todo.text}`);

          // Sound notification
          const audio = new Audio(
            "https://actions.google.com/sounds/v1/alarms/beep_short.ogg"
          );
          audio.play().catch((e) => console.log("Audio play failed:", e));
        }
      });
    };

    const interval = setInterval(checkTaskAnnouncements, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [todos]);

  return (
    <div className="flex flex-col items-center mt-6 space-y-4 p-4 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-semibold text-gray-800">🕒 To-Do Clock</h2>
      <canvas
        ref={canvasRef}
        width={400}
        height={400}
        className="bg-gray-50 rounded-full border-2 border-gray-200"
      />
      <div className="flex gap-4">
        <button
          onClick={exportPNG}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded transition-colors"
        >
          Export PNG
        </button>
        <button
          onClick={exportSVG}
          className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded transition-colors"
        >
          Export SVG
        </button>
      </div>
      <div className="text-sm text-gray-600 mt-2 text-center">
        <p>
          Tasks are displayed at their scheduled times with colored indicators.
        </p>
        <p>You'll receive notifications when task times are reached.</p>
      </div>
    </div>
  );
}
