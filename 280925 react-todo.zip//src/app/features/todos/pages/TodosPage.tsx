//TodosPage.tsx

import { useState, useEffect } from "react";
import {
  addTodo,
  getTodos,
  Todo,
  clearAllTodos,
  exportTodos,
  importTodos,
  updateTodoTime,
} from "../../../core/services/todoService";

import { TodoStatus } from "../../../core/utils/constants";

import TodoList from "../components/TodoList";
import DoneList from "../components/DoneList";
import DeletedList from "../components/DeletedList";
import TodoSandglass from "../components/TodoSandglass";
import ClockCanvas from "../components/ClockCanvas";

export default function TodosPage() {
  const [todos, setTodos] = useState<Todo[]>(getTodos());
  const [newTodo, setNewTodo] = useState("");
  const [time, setTime] = useState("12:00");
  const [activeView, setActiveView] = useState<
    "columns" | "sandglass" | "clock"
  >("columns");
  const [showDataTools, setShowDataTools] = useState(false);
  const [importData, setImportData] = useState("");

  const refresh = () => setTodos([...getTodos()]);

  const handleAdd = () => {
    if (newTodo.trim()) {
      addTodo(newTodo, time);
      setNewTodo("");
      setTime("12:00");
      refresh();
    }
  };

  const handleExportData = () => {
    const data = exportTodos();
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "todos-backup.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportData = () => {
    if (importTodos(importData)) {
      refresh();
      setImportData("");
      setShowDataTools(false);
      alert("Data imported successfully!");
    } else {
      alert("Error importing data. Please check the format.");
    }
  };

  const handleClearAll = () => {
    if (
      window.confirm(
        "Are you sure you want to delete all todos? This cannot be undone."
      )
    ) {
      clearAllTodos();
      refresh();
      setShowDataTools(false);
    }
  };

  // Filter todos for different views
  const activeTodos = todos.filter((t) => t.status === TodoStatus.ACTIVE);
  const doneTodos = todos.filter((t) => t.status === TodoStatus.DONE);
  const deletedTodos = todos.filter((t) => t.status === TodoStatus.DELETED);
  const todosWithTime = todos.filter((todo) => todo.time);

  // Check for todos without time
  const todosWithoutTime = activeTodos.filter((todo) => !todo.time);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            My To-Do App
          </h1>
          <p className="text-gray-600 mb-6">
            Organize your tasks with time-based scheduling
          </p>

          {/* Add task with time */}
          <div className="flex flex-col lg:flex-row gap-3">
            <div className="flex-1 flex flex-col sm:flex-row gap-2">
              <input
                value={newTodo}
                onChange={(e) => setNewTodo(e.target.value)}
                className="flex-1 border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="What needs to be done?"
                onKeyPress={(e) => e.key === "Enter" && handleAdd()}
              />
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <button
              onClick={handleAdd}
              className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg transition-colors duration-200 font-medium"
            >
              Add Task
            </button>
          </div>
        </div>

        {/* Bulk time setter for existing todos */}
        {todosWithoutTime.length > 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h3 className="font-semibold text-yellow-800 mb-1">
                  Missing Time Settings
                </h3>
                <p className="text-yellow-700 text-sm">
                  {todosWithoutTime.length} active task
                  {todosWithoutTime.length !== 1 ? "s" : ""} don't have times
                  set.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                />
                <button
                  onClick={() => {
                    todosWithoutTime.forEach((todo) => {
                      updateTodoTime(todo.id, time);
                    });
                    refresh();
                  }}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                >
                  Set Time for All
                </button>
              </div>
            </div>
          </div>
        )}

        {/* View Toggle Buttons */}
        <div className="flex flex-wrap gap-2 mb-6 justify-center">
          <button
            onClick={() => setActiveView("columns")}
            className={`px-6 py-3 rounded-lg transition-all duration-200 font-medium ${
              activeView === "columns"
                ? "bg-blue-500 text-white shadow-md"
                : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
            }`}
          >
            📋 Column View
          </button>
          <button
            onClick={() => setActiveView("sandglass")}
            className={`px-6 py-3 rounded-lg transition-all duration-200 font-medium ${
              activeView === "sandglass"
                ? "bg-blue-500 text-white shadow-md"
                : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
            }`}
          >
            ⏳ Time Period View
          </button>
          <button
            onClick={() => setActiveView("clock")}
            className={`px-6 py-3 rounded-lg transition-all duration-200 font-medium ${
              activeView === "clock"
                ? "bg-blue-500 text-white shadow-md"
                : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
            }`}
          >
            🕒 Clock View
          </button>
        </div>

        {/* Conditional rendering based on active view */}
        {activeView === "columns" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">
                  Active Tasks
                </h2>
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                  {activeTodos.length}
                </span>
              </div>
              <TodoList todos={activeTodos} refresh={refresh} />
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">
                  Completed Tasks
                </h2>
                <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                  {doneTodos.length}
                </span>
              </div>
              <DoneList todos={doneTodos} refresh={refresh} />
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">
                  Deleted Tasks
                </h2>
                <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
                  {deletedTodos.length}
                </span>
              </div>
              <DeletedList todos={deletedTodos} refresh={refresh} />
            </div>
          </div>
        )}

        {activeView === "sandglass" && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">
                  Active Tasks by Time
                </h2>
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                  {activeTodos.length}
                </span>
              </div>
              <TodoSandglass todos={activeTodos} />
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">
                  Completed Tasks by Time
                </h2>
                <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                  {doneTodos.length}
                </span>
              </div>
              <TodoSandglass todos={doneTodos} />
            </div>
          </div>
        )}

        {activeView === "clock" && (
          <div className="mb-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">
                  Task Clock Visualization
                </h2>
                <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">
                  {todosWithTime.length} with time
                </span>
              </div>

              {todosWithTime.length === 0 ? (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-8 text-center">
                  <div className="text-6xl mb-4">🕒</div>
                  <h3 className="text-lg font-semibold text-blue-800 mb-2">
                    No tasks with time set
                  </h3>
                  <p className="text-blue-700">
                    Add time to your tasks to see them visualized on the clock
                  </p>
                </div>
              ) : (
                <ClockCanvas todos={todosWithTime} />
              )}
            </div>
          </div>
        )}

        {/* Data Management Tools */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <button
            onClick={() => setShowDataTools(!showDataTools)}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4 font-medium"
          >
            <span className="text-lg">{showDataTools ? "▼" : "▶"}</span>
            Data Management Tools
          </button>

          {showDataTools && (
            <div className="space-y-4 border-t pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800">
                    Backup & Restore
                  </h4>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={handleExportData}
                      className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors flex items-center gap-2"
                    >
                      💾 Export Data
                    </button>
                    <button
                      onClick={handleClearAll}
                      className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors flex items-center gap-2"
                    >
                      🗑️ Clear All Data
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800">Import Data</h4>
                  <textarea
                    value={importData}
                    onChange={(e) => setImportData(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg p-3 text-sm h-20 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Paste your JSON backup data here..."
                  />
                  <button
                    onClick={handleImportData}
                    disabled={!importData.trim()}
                    className={`w-full px-4 py-2 rounded text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
                      importData.trim()
                        ? "bg-blue-500 hover:bg-blue-600 text-white"
                        : "bg-gray-200 text-gray-500 cursor-not-allowed"
                    }`}
                  >
                    📥 Import Data
                  </button>
                </div>
              </div>

              <div className="text-xs text-gray-500 bg-gray-50 p-3 rounded-lg">
                <p className="font-medium mb-1">💡 Storage Information</p>
                <p>
                  • Data is automatically saved to your browser's localStorage
                </p>
                <p>• Your todos will persist between browser sessions</p>
                <p>• Export your data regularly for backup</p>
              </div>
            </div>
          )}
        </div>

        {/* Stats Footer */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {todos.length}
              </div>
              <div className="text-sm text-blue-800">Total Tasks</div>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {activeTodos.length}
              </div>
              <div className="text-sm text-green-800">Active</div>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">
                {doneTodos.length}
              </div>
              <div className="text-sm text-yellow-800">Completed</div>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">
                {deletedTodos.length}
              </div>
              <div className="text-sm text-red-800">Deleted</div>
            </div>
          </div>

          <div className="mt-4 text-center text-sm text-gray-600">
            <span className="inline-flex items-center gap-1 bg-green-100 text-green-800 px-3 py-1 rounded-full">
              💾 Auto-saved
            </span>
            <span className="mx-2">•</span>
            <span>Tasks with time: {todos.filter((t) => t.time).length}</span>
            <span className="mx-2">•</span>
            <span>Without time: {todos.filter((t) => !t.time).length}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
