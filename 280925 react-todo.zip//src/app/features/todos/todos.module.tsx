// todos.module.tsx

import TodosPage from "./pages/TodosPage";

export default TodosPage;
