// MainLayout.tsx

import { Outlet } from "react-router-dom";

export default function MainLayout() {
  return (
    <div className="max-w-3xl mx-auto">
      <header className="bg-blue-600 text-white p-4 text-xl font-bold">
        To-Do App
      </header>
      <main className="p-4">
        <Outlet />
      </main>
    </div>
  );
}
